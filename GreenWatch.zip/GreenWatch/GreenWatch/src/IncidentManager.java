import java.sql.*;
import java.util.Scanner;

import com.mysql.cj.xdevapi.SelectStatement;

public class IncidentManager {
    static final String JDBC_DRIVER = "com.mysql.cj.jdbc.Driver";
    static final String DB_URL = "jdbc:mysql://localhost/greenwatch";
    static final String USER = "root";
    static final String PASS = "";

    public static void main(String[] args) {
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASS)) {
            criarTabela(connection);

            boolean executando = true;
            Scanner scanner = new Scanner(System.in);

            while (executando) {
                System.out.println("Escolha uma opção:");
                System.out.println("1 - Cadastrar incidente");
                System.out.println("2 - Editar incidente");
                System.out.println("3 - Deletar incidente");
                System.out.println("4 - Listar incidentes");
                System.out.println("5 - Sair");

                int opcao = scanner.nextInt();
                scanner.nextLine(); // Consumir a nova linha após o nextInt()

                switch (opcao) {
                    case 1:
                        cadastrarIncidente(connection, scanner);
                        break;
                    case 2:
                        editarIncidente(connection, scanner);
                        break;
                    case 3:
                        deletarIncidente(connection, scanner);
                        break;
                    case 4:
                        listarIncidentes(connection);
                        break;
                    case 5:
                        executando = false;
                        break;
                    default:
                        System.out.println("Opção inválida!");
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void criarTabela(Connection connection) throws SQLException {
        String sql = "CREATE TABLE IF NOT EXISTS incidentes (" +
                     "id INT AUTO_INCREMENT PRIMARY KEY," +
                     "descricao VARCHAR(255) NOT NULL," +
                     "localizacao VARCHAR(255) NOT NULL," +
                     "nome_usuario VARCHAR(100)," +
                     "email_usuario VARCHAR(100)" +
                     ")";
        
        try (Statement statement = connection.createStatement()) {
            statement.executeUpdate(sql);
        }
    }

    private static void cadastrarIncidente(Connection connection, Scanner scanner) throws SQLException {
        System.out.println("Deseja se cadastrar? (s/n)");
        String resposta = scanner.nextLine();

        String descricao;
        String localizacao;
        String nomeUsuario = null;
        String emailUsuario = null;

        if (resposta.equalsIgnoreCase("s")) {
            System.out.println("Digite seu nome:");
            nomeUsuario = scanner.nextLine();
            System.out.println("Digite seu email:");
            emailUsuario = scanner.nextLine();
        }

        System.out.println("Digite a descrição do incidente:");
        descricao = scanner.nextLine();
        System.out.println("Digite a localização do incidente:");
        localizacao = scanner.nextLine();

        String sql = "INSERT INTO incidentes (descricao, localizacao, nome_usuario, email_usuario) VALUES (?, ?, ?, ?)";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, descricao);
            statement.setString(2, localizacao);
            statement.setString(3, nomeUsuario);
            statement.setString(4, emailUsuario);
            statement.executeUpdate();
            }
           
        System.out.println("Incidente cadastrado com sucesso!\n");
}

    private static void editarIncidente(Connection connection, Scanner scanner) throws SQLException {
        System.out.println("Digite o ID do incidente que deseja editar:");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consumir a nova linha após o nextInt()

        System.out.println("Digite a nova descrição:");
        String novaDescricao = scanner.nextLine();
        System.out.println("Digite a nova localização:");
        String novaLocalizacao = scanner.nextLine();

        String sql = "UPDATE incidentes SET descricao = ?, localizacao = ? WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setString(1, novaDescricao);
            statement.setString(2, novaLocalizacao);
            statement.setInt(3, id);
            int linhasAfetadas = statement.executeUpdate();
            if (linhasAfetadas == 0) {
                System.out.println("Incidente não encontrado!\n");
            } else {
                System.out.println("Incidente editado com sucesso!\n");
            }
        }
    }

    private static void deletarIncidente(Connection connection, Scanner scanner) throws SQLException {
        System.out.println("Digite o ID do incidente que deseja deletar:");
        int id = scanner.nextInt();
        scanner.nextLine(); // Consumir a nova linha após o nextInt()

        String sql = "DELETE FROM incidentes WHERE id = ?";
        try (PreparedStatement statement = connection.prepareStatement(sql)) {
            statement.setInt(1, id);
            int linhasAfetadas = statement.executeUpdate();
            if (linhasAfetadas == 0) {
                System.out.println("Incidente não encontrado!\n");
            } else {
                System.out.println("Incidente deletado com sucesso!\n");
            }
        }
    }

    private static void listarIncidentes(Connection connection) throws SQLException {
        String sql = "SELECT * FROM incidentes";
        try (Statement statement = connection.createStatement();
             ResultSet resultSet = statement.executeQuery(sql)) {
            if (!resultSet.isBeforeFirst()) {
                System.out.println("Não há incidentes cadastrados!\n");
            } else {
                System.out.println("Lista de incidentes:");
                while (resultSet.next()) {
                    System.out.println("ID: " + resultSet.getInt("id"));
                    System.out.println("Descrição: " + resultSet.getString("descricao"));
                    System.out.println("Localização: " + resultSet.getString("localizacao"));
                    System.out.println("Nome do usuário: " + resultSet.getString("nome_usuario"));
                    System.out.println("Email do usuário: " + resultSet.getString("email_usuario"));
                    System.out.println();
                }
            }
        }
    }
}

